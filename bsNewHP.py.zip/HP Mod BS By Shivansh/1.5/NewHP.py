import bs
from bsSpaz import Spaz

Spaz._old_init = Spaz.__init__
def _new_init(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5),
              character="Spaz", sourcePlayer=None, startInvincible=True,
              canAcceptPowerups=True, powerupsExpire=False, demoMode=False):
    self._old_init(color,highlight,character,sourcePlayer,
                   startInvincible,canAcceptPowerups,
                   powerupsExpire,demoMode)
    def _new_hp():
        if self.node is None and not self.node.exists():
            return
        hp = bs.newNode('math',
                        owner=self.node,
                        attrs={
                            'input1': (
                                0, 1.37, 0) if self.sourcePlayer.exists(
                                ) else (0, 1.20, 0),
                            'operation': 'add'
                        })
        self.node.connectAttr('torsoPosition', hp, 'input2')
        self.hp = bs.newNode('text',
                             owner=self.node,
                             attrs={
                                'text': '',
                                'inWorld': True,
                                'shadow': 1.0,
                                'flatness': 1.0,
                                'scale': 0.012,
                                'hAlign': 'center',
                             })
        hp.connectAttr('output', self.hp, 'position')
        bs.animate(self.hp, 'scale', {0:0, 200:0, 600:0.018, 800:0.012})

        def _update():
            if not self.hp.exists():
                return
            if self.shield is not None and self.shield.exists():
                hptext = int(
                    (self.shieldHitPoints/self.shieldHitPointsMax)*100)
            else:
                hptext = int(self.hitPoints*0.1)
            if hptext >= 75:
                color = (0.2, 1.0, 0.2)
            elif hptext >= 50:
                color = (1.0, 1.0, 0.2)
            elif hptext >= 25:
                color = (1.0, 0.5, 0.2)
            else:
                color = (1.0, 0.2, 0.2)
            self.hp.text = 'HP -:' + str(hptext) + '%'
            self.hp.color = (0.2, 1.0, 0.8) if self.shield else color
        bs.gameTimer(50, _update, repeat=True)
    _new_hp()
    # app = _ba.app
    # cfg = app.config
    # new_hp = cfg.get('New HP', True)
    # if new_hp:
    #     _new_hp()

Spaz.__init__ = _new_init
